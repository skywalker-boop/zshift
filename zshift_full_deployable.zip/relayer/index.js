require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { ethers } = require('ethers');

const ABI = [
  'function mint(address to, uint256 amount) external',
  'function balanceOf(address) view returns (uint256)'
];

const app = express();
app.use(cors());
app.use(bodyParser.json());

const RPC = process.env.BASE_SEPOLIA_RPC;
const DEPLOYED = process.env.CONTRACT_ADDRESS;
const KEY = process.env.DEPLOYER_KEY;

if (!RPC || !DEPLOYED || !KEY) {
  console.error('Missing BASE_SEPOLIA_RPC, CONTRACT_ADDRESS, or DEPLOYER_KEY in .env');
  process.exit(1);
}

const provider = new ethers.providers.JsonRpcProvider(RPC);
const wallet = new ethers.Wallet(KEY, provider);
const contract = new ethers.Contract(DEPLOYED, ABI, wallet);

const usedNonces = new Set();

app.post('/intent', async (req, res) => {
  try {
    const { to, amount, signature, message } = req.body;
    if (!to || !amount || !signature || !message) return res.status(400).send('missing fields');

    const signer = ethers.utils.verifyMessage(message, signature);
    if (signer.toLowerCase() !== to.toLowerCase()) return res.status(400).send('signature mismatch');

    const match = message.match(/nonce:([a-z0-9]+)/i);
    if (!match) return res.status(400).send('invalid message format');
    const nonce = match[1];
    if (usedNonces.has(nonce)) return res.status(400).send('replay detected');
    usedNonces.add(nonce);

    const tsMatch = message.match(/ts:(\d+)/);
    if (tsMatch) {
      const ts = parseInt(tsMatch[1], 10);
      const now = Math.floor(Date.now()/1000);
      if (Math.abs(now - ts) > 300) return res.status(400).send('timestamp expired');
    }

    console.log(`Minting ${amount} to ${to} per intent...`);
    const tx = await contract.mint(to, ethers.BigNumber.from(amount));
    await tx.wait();
    return res.json({ success: true, txHash: tx.hash });
  } catch (e) {
    console.error(e);
    return res.status(500).send(e.toString());
  }
});

app.get('/balance/:addr', async (req, res) => {
  try {
    const bal = await contract.balanceOf(req.params.addr);
    res.json({ balance: bal.toString() });
  } catch (e) { res.status(500).send(e.toString()); }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log('Relayer running on', PORT));
