Starter template:
- React Vite app in frontend/ ready for extension
- Hardhat contract + deploy script in hardhat/
- Simple relayer in relayer/
Use this as your baseline to develop features fast.
