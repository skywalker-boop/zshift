async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying with", deployer.address);

  const ZShift = await ethers.getContractFactory("ZShiftOFT");
  const name = "ZShiftToken";
  const symbol = "ZSHFT";
  const lzEndpoint = process.env.LZ_ENDPOINT;
  if (!lzEndpoint) throw new Error("Please set LZ_ENDPOINT in .env");

  const zshift = await ZShift.deploy(name, symbol, lzEndpoint);
  await zshift.deployed();
  console.log("ZShift deployed to:", zshift.address);
}

main().catch((e) => { console.error(e); process.exit(1); });
