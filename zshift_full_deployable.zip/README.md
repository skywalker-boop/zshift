# ZShift — Full Deployable Demo Bundle

This bundle contains everything for an investor-ready demo:
- Landing page (landing/)
- Mock functional UI (frontend/ - React Vite app)
- Fully functional frontend ready to connect to your backend (frontend/)
- Starter template (starter/)
- Smart contract and Hardhat config (contracts/, hardhat/)
- Relayer (relayer/)
- .env.example and deployment instructions

Original uploaded archive (included for reference):
/mnt/data/zshift_v2_OFT_full_auto.zip

## Quick steps
1. Unzip and inspect files.
2. Fill `.env` in `hardhat` and `relayer` with RPC keys and deployer key.
3. Deploy contract with hardhat, update CONTRACT_ADDRESS in relayer .env
4. Start relayer: `node relayer/index.js`
5. Run frontend: `cd frontend && npm install && npm run dev`
6. Build landing or frontend and deploy to Vercel/Netlify.

See each folder README for details.
